
import React from 'react';
import { Search, Bell, Globe, LogOut } from 'lucide-react';
import { Language, AppUser } from '../types';
import { TRANSLATIONS } from '../constants';

interface HeaderProps {
  lang: Language;
  setLang: (lang: Language) => void;
  user: AppUser | null;
  onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ lang, setLang, user, onLogout }) => {
  const t = TRANSLATIONS[lang];

  return (
    <header className="h-14 bg-white border-b border-gray-200 px-6 flex items-center justify-between sticky top-0 z-40">
      <div className="flex items-center flex-1 max-w-lg">
        <div className="relative w-full group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-indigo-600 transition-colors" size={16} />
          <input 
            type="text" 
            placeholder="Search everything..." 
            className="w-full pl-10 pr-4 py-1.5 bg-gray-100/50 border border-transparent rounded-lg focus:bg-white focus:border-indigo-500 transition-all outline-none text-xs font-medium"
          />
        </div>
      </div>

      <div className="flex items-center gap-4">
        <button 
          onClick={() => setLang(lang === 'EN' ? 'BN' : 'EN')}
          className="flex items-center gap-2 px-3 py-1 rounded-full hover:bg-gray-100 text-[10px] font-black uppercase tracking-widest transition-colors border border-gray-200 text-slate-600"
        >
          <Globe size={14} className="text-indigo-600" />
          <span>{lang === 'EN' ? 'বাংলা' : 'English'}</span>
        </button>

        <div className="h-4 w-[1px] bg-gray-200"></div>

        <button className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-full transition-all relative">
          <Bell size={18} />
          <span className="absolute top-2 right-2 w-1.5 h-1.5 bg-red-500 rounded-full border-2 border-white"></span>
        </button>

        <div className="flex items-center gap-3 py-1 px-1 pr-3 bg-slate-50 border border-slate-100 rounded-full hover:bg-slate-100 transition-all cursor-pointer">
          <div className="w-7 h-7 rounded-full bg-indigo-600 text-white flex items-center justify-center font-black text-[10px] shadow-sm">
            {user?.name.split(' ').map(n => n[0]).join('')}
          </div>
          <div className="hidden sm:block">
            <p className="text-[10px] font-black text-slate-800 leading-none truncate w-20">{user?.name}</p>
          </div>
        </div>

        <button 
          onClick={onLogout}
          className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-full transition-all group"
          title={t.logout}
        >
          <LogOut size={18} className="group-hover:translate-x-0.5 transition-transform" />
        </button>
      </div>
    </header>
  );
};

export default Header;
