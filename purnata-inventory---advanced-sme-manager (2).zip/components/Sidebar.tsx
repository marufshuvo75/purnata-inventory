
import React from 'react';
import { MENU_ITEMS, TRANSLATIONS } from '../constants';
import { AppUser, Language } from '../types';

interface SidebarProps {
  lang: Language;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  user: AppUser | null;
}

const Sidebar: React.FC<SidebarProps> = ({ lang, activeTab, setActiveTab, user }) => {
  const t = TRANSLATIONS[lang];

  return (
    <div className="w-60 bg-slate-900 text-white flex flex-col shrink-0 hidden lg:flex border-r border-slate-800">
      <div className="p-5 flex items-center gap-3">
        <div className="w-9 h-9 bg-indigo-600 rounded-lg flex items-center justify-center font-black text-lg shadow-lg shadow-indigo-600/20">P</div>
        <div className="flex flex-col">
          <span className="text-sm font-black tracking-tighter leading-none">PURNATA</span>
          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Inventory v2.0</span>
        </div>
      </div>
      
      <nav className="flex-1 px-3 py-4 space-y-0.5">
        {MENU_ITEMS.map((item) => {
          if (!user?.permissions.includes(item.id)) return null;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all text-sm font-semibold ${
                activeTab === item.id 
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/10' 
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <span className={activeTab === item.id ? 'text-white' : 'text-slate-500'}>
                {item.icon}
              </span>
              <span>{t[item.label as keyof typeof t]}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-800/50">
        <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-xs font-black ring-1 ring-indigo-500/30">
              {user?.name.charAt(0)}
            </div>
            <div className="min-w-0">
              <p className="text-[11px] font-black text-white truncate">{user?.name}</p>
              <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest">{user?.role}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
