
import React, { useState } from 'react';
import { Language, Loan, UserRole } from '../types';
import { TRANSLATIONS } from '../constants';
import { Wallet, Plus, Calendar, CreditCard, ChevronRight, X } from 'lucide-react';

interface LoansViewProps {
  lang: Language;
  loans: Loan[];
  role: UserRole;
  onAddLoan: (l: Omit<Loan, 'id'>) => Promise<void>;
  onPayLoan: (id: string, amount: number) => Promise<void>;
}

const LoansView: React.FC<LoansViewProps> = ({ lang, loans, role, onAddLoan, onPayLoan }) => {
  const t = TRANSLATIONS[lang];
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [newLoan, setNewLoan] = useState({
    provider: '',
    amount: 0,
    interestRate: 0,
    monthlyInstallment: 0,
    paidAmount: 0,
    startDate: new Date().toISOString().split('T')[0],
    endDate: '',
    nextPaymentDate: ''
  });

  if (role === UserRole.STAFF) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center p-8 bg-white rounded-2xl border border-slate-200 max-w-sm">
          <div className="w-16 h-16 bg-amber-50 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-4"><CreditCard size={32} /></div>
          <h3 className="text-lg font-bold text-slate-800 mb-2">Access Denied</h3>
          <p className="text-slate-500 text-sm">You do not have the required permissions to access financial loan records.</p>
        </div>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await onAddLoan(newLoan);
      setIsModalOpen(false);
      setNewLoan({ provider: '', amount: 0, interestRate: 0, monthlyInstallment: 0, paidAmount: 0, startDate: new Date().toISOString().split('T')[0], endDate: '', nextPaymentDate: '' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">{t.loans}</h1>
          <p className="text-slate-500 text-sm">Track business liabilities and EMI schedules</p>
        </div>
        <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 font-medium transition-all shadow-md text-sm"><Plus size={18} />Add New Loan</button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {loans.map(loan => {
          const progress = (loan.paidAmount / loan.amount) * 100;
          const remaining = loan.amount - loan.paidAmount;
          return (
            <div key={loan.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
              <div className="p-6 border-b border-slate-100 flex justify-between items-start">
                <div>
                  <h4 className="text-lg font-bold text-slate-800">{loan.provider}</h4>
                  <p className="text-xs text-slate-500 font-medium">{loan.interestRate}% Interest Rate</p>
                </div>
                <div className="px-2 py-1 bg-green-50 text-green-700 text-[10px] font-bold rounded uppercase tracking-wider">Active</div>
              </div>
              <div className="p-6 flex-1 space-y-6">
                <div>
                  <div className="flex justify-between text-sm mb-2"><span className="text-slate-500">Repayment Progress</span><span className="font-bold text-indigo-600">{progress.toFixed(1)}%</span></div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden"><div className="h-full bg-indigo-600 transition-all duration-500" style={{ width: `${progress}%` }}></div></div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-slate-50 rounded-xl"><p className="text-[10px] text-slate-400 font-bold uppercase mb-1">Total Loan</p><p className="text-sm font-bold text-slate-800">{t.currency}{loan.amount.toLocaleString()}</p></div>
                  <div className="p-3 bg-slate-50 rounded-xl"><p className="text-[10px] text-slate-400 font-bold uppercase mb-1">Monthly EMI</p><p className="text-sm font-bold text-slate-800">{t.currency}{loan.monthlyInstallment.toLocaleString()}</p></div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 text-sm text-slate-600"><Calendar size={16} className="text-slate-400 shrink-0" /><span>Next Due: <span className="font-bold text-slate-800">{loan.nextPaymentDate}</span></span></div>
                  <div className="flex items-center gap-3 text-sm text-slate-600"><Wallet size={16} className="text-slate-400 shrink-0" /><span>Total Due: <span className="font-bold text-slate-800">{t.currency}{remaining.toLocaleString()}</span></span></div>
                </div>
              </div>
              <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                <button className="text-sm font-bold text-indigo-600 hover:text-indigo-700">View Transactions</button>
                <button onClick={() => onPayLoan(loan.id, loan.monthlyInstallment)} className="flex items-center gap-1 text-sm font-bold text-slate-700 hover:text-slate-900">Pay Installment<ChevronRight size={16} /></button>
              </div>
            </div>
          );
        })}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <form onSubmit={handleSubmit} className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h2 className="text-xl font-bold text-slate-800">Add Loan Facility</h2>
              <button type="button" onClick={() => setIsModalOpen(false)} className="p-2 text-slate-400 hover:text-slate-600 rounded-full"><X size={20} /></button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Provider (Bank/Entity)</label>
                <input required value={newLoan.provider} onChange={e => setNewLoan(p => ({...p, provider: e.target.value}))} type="text" className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:border-indigo-500 transition-all" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Total Loan Amount</label>
                  <input required value={newLoan.amount} onChange={e => setNewLoan(p => ({...p, amount: parseFloat(e.target.value)}))} type="number" className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Interest Rate (%)</label>
                  <input required value={newLoan.interestRate} onChange={e => setNewLoan(p => ({...p, interestRate: parseFloat(e.target.value)}))} type="number" step="0.01" className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Monthly EMI</label>
                  <input required value={newLoan.monthlyInstallment} onChange={e => setNewLoan(p => ({...p, monthlyInstallment: parseFloat(e.target.value)}))} type="number" className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Next Payment Date</label>
                  <input required value={newLoan.nextPaymentDate} onChange={e => setNewLoan(p => ({...p, nextPaymentDate: e.target.value}))} type="date" className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none" />
                </div>
              </div>
            </div>
            <div className="p-6 bg-slate-50 flex justify-end gap-3 border-t border-slate-100">
              <button type="button" onClick={() => setIsModalOpen(false)} className="px-6 py-2 text-slate-600 font-bold">Cancel</button>
              <button disabled={submitting} type="submit" className="px-8 py-2 bg-slate-900 text-white rounded-lg font-bold shadow-lg hover:bg-slate-800 transition-all">{submitting ? 'Saving...' : 'Add Loan'}</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default LoansView;
