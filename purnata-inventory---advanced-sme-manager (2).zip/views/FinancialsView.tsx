
import React, { useState, useCallback, useMemo } from 'react';
import { Language, Income, Expense, FinanceCategory, PaymentMethod, Order } from '../types';
import { TRANSLATIONS } from '../constants';
import { Plus, Download, ArrowUpRight, ArrowDownRight, X, Loader2, Calculator, Calendar } from 'lucide-react';
import { financeService } from '../services/financeService';

interface FinancialsViewProps {
  lang: Language;
  incomes: Income[];
  onAddIncome: (i: Omit<Income, 'id'>) => Promise<void>;
  expenses: Expense[];
  onAddExpense: (e: Omit<Expense, 'id'>) => Promise<void>;
  orders: Order[];
}

const FinancialsView: React.FC<FinancialsViewProps> = React.memo(({ lang, incomes, onAddIncome, expenses, onAddExpense, orders }) => {
  const t = TRANSLATIONS[lang];
  const [activeTab, setActiveTab] = useState<'INCOME' | 'EXPENSE' | 'REPORTS'>('INCOME');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Auto-calculated summary
  const summary = useMemo(() => 
    financeService.calculateFinancials(incomes, expenses, orders), 
  [incomes, expenses, orders]);

  const [formData, setFormData] = useState({
    amount: 0,
    category: FinanceCategory.OTHER,
    date: new Date().toISOString().split('T')[0],
    method: PaymentMethod.CASH,
    note: ''
  });

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      if (activeTab === 'INCOME') {
        await onAddIncome({ ...formData, source: formData.category });
      } else {
        await onAddExpense(formData);
      }
      setIsModalOpen(false);
      setFormData({ amount: 0, category: FinanceCategory.OTHER, date: new Date().toISOString().split('T')[0], method: PaymentMethod.CASH, note: '' });
    } finally {
      setSubmitting(false);
    }
  }, [formData, activeTab, onAddIncome, onAddExpense]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-black text-slate-900 tracking-tight">{t.financials}</h1>
          <p className="text-slate-500 text-xs font-medium">Automatic Profit & Loss Balancing</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-slate-50 transition-all"><Download size={14} className="inline mr-2"/>Export CSV</button>
          <button onClick={() => setIsModalOpen(true)} className="px-5 py-2 bg-indigo-600 text-white rounded-lg text-[10px] font-black uppercase tracking-widest shadow-lg shadow-indigo-600/20 hover:bg-indigo-700 transition-all"><Plus size={14} className="inline mr-1"/>Record Entry</button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <SummaryCard label="Total Revenue (Inc. Sales)" value={summary.total.income} icon={<ArrowUpRight size={20}/>} color="text-green-600 bg-green-50" />
        <SummaryCard label="Total Operating Expense" value={summary.total.expense} icon={<ArrowDownRight size={20}/>} color="text-red-600 bg-red-50" />
        <SummaryCard label="Net Business Profit" value={summary.total.profit} icon={<Calculator size={20}/>} color="text-indigo-600 bg-indigo-50" />
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="flex border-b border-slate-100 bg-slate-50/50">
          <button onClick={() => setActiveTab('INCOME')} className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'INCOME' ? 'text-indigo-600 border-b-2 border-indigo-600 bg-white' : 'text-slate-400'}`}>Income History</button>
          <button onClick={() => setActiveTab('EXPENSE')} className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'EXPENSE' ? 'text-indigo-600 border-b-2 border-indigo-600 bg-white' : 'text-slate-400'}`}>Expense History</button>
          <button onClick={() => setActiveTab('REPORTS')} className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'REPORTS' ? 'text-indigo-600 border-b-2 border-indigo-600 bg-white' : 'text-slate-400'}`}>P&L Report</button>
        </div>

        <div className="overflow-x-auto">
          {activeTab === 'REPORTS' ? (
            <table className="w-full text-left">
              <thead>
                <tr className="bg-white text-slate-400 text-[9px] uppercase font-black tracking-widest border-b border-slate-50">
                  <th className="px-6 py-4">Month</th>
                  <th className="px-6 py-4 text-right">Income (৳)</th>
                  <th className="px-6 py-4 text-right">Expense (৳)</th>
                  <th className="px-6 py-4 text-right">Net Profit (৳)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {summary.monthly.map(item => (
                  <tr key={item.month} className="hover:bg-slate-50 transition-all duration-75">
                    <td className="px-6 py-4 text-[10px] font-black text-slate-800 flex items-center gap-2">
                      <Calendar size={14} className="text-slate-300" />
                      {item.month}
                    </td>
                    <td className="px-6 py-4 text-right text-[10px] font-black text-green-600">{item.income.toLocaleString()}</td>
                    <td className="px-6 py-4 text-right text-[10px] font-black text-red-600">{item.expense.toLocaleString()}</td>
                    <td className={`px-6 py-4 text-right text-sm font-black ${item.profit >= 0 ? 'text-indigo-600' : 'text-red-800'}`}>{t.currency}{item.profit.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table className="w-full text-left">
              <thead>
                <tr className="bg-white text-slate-400 text-[9px] uppercase font-black tracking-widest border-b border-slate-50">
                  <th className="px-6 py-4">Date</th>
                  <th className="px-6 py-4">Category</th>
                  <th className="px-6 py-4">Method</th>
                  <th className="px-6 py-4 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {(activeTab === 'INCOME' ? incomes : expenses).map(item => (
                  <tr key={item.id} className="hover:bg-slate-50 transition-all duration-75">
                    <td className="px-6 py-4 text-[10px] font-black text-slate-800">{item.date}</td>
                    <td className="px-6 py-4 text-[9px] font-black uppercase tracking-widest text-slate-500">{(item as any).source || (item as any).category}</td>
                    <td className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">{item.method}</td>
                    <td className={`px-6 py-4 text-right text-sm font-black ${activeTab === 'INCOME' ? 'text-green-600' : 'text-slate-900'}`}>{t.currency}{item.amount.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4 animate-in fade-in duration-100">
          <form onSubmit={handleSubmit} className="bg-white rounded-2xl w-full max-w-md shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h2 className="text-lg font-black text-slate-800 uppercase tracking-tight">Add {activeTab === 'REPORTS' ? 'Financial Record' : activeTab}</h2>
              <button type="button" onClick={() => setIsModalOpen(false)} className="p-2 text-slate-400 hover:bg-slate-200 rounded-full"><X size={18} /></button>
            </div>
            <div className="p-6 space-y-4">
              <input required type="number" placeholder="Amount" value={formData.amount || ''} onChange={e => setFormData(p => ({...p, amount: parseFloat(e.target.value)}))} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-lg font-black outline-none focus:border-indigo-500" />
              <div className="grid grid-cols-2 gap-4">
                <select value={formData.category} onChange={e => setFormData(p => ({...p, category: e.target.value as FinanceCategory}))} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-[10px] font-black uppercase tracking-widest outline-none">
                  {Object.values(FinanceCategory).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                </select>
                <select value={formData.method} onChange={e => setFormData(p => ({...p, method: e.target.value as PaymentMethod}))} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-[10px] font-black uppercase tracking-widest outline-none">
                  {Object.values(PaymentMethod).map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
              <input placeholder="Note" value={formData.note} onChange={e => setFormData(p => ({...p, note: e.target.value}))} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold outline-none" />
            </div>
            <div className="p-6 bg-slate-50 flex justify-end gap-3">
              <button type="button" onClick={() => setIsModalOpen(false)} className="px-6 py-2 text-slate-400 font-black uppercase text-[10px]">Cancel</button>
              <button disabled={submitting} type="submit" className={`px-8 py-2 rounded-lg font-black uppercase tracking-widest text-[10px] text-white shadow-lg flex items-center gap-2 ${(activeTab === 'INCOME' || activeTab === 'REPORTS') ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}`}>
                {submitting ? <Loader2 className="animate-spin" size={14}/> : 'Record Entry'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
});

const SummaryCard = ({ label, value, icon, color }: any) => (
  <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4 transition-all duration-75 hover:scale-[1.01] hover:shadow-md">
    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color} shadow-sm`}>{icon}</div>
    <div>
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 leading-none">{label}</p>
      <h4 className="text-xl font-black text-slate-900 leading-none">৳{value.toLocaleString()}</h4>
    </div>
  </div>
);

export default FinancialsView;
