
import React, { useState, useEffect } from 'react';
import { 
  Language, 
  Order, 
  OrderStatus, 
  Product, 
  CourierType 
} from '../types';
import { TRANSLATIONS, STATUS_COLORS } from '../constants';
import { 
  ArrowLeft, 
  User, 
  Phone, 
  MapPin, 
  Truck, 
  Calendar, 
  Package, 
  CreditCard, 
  CheckCircle, 
  XCircle,
  Clock,
  ChevronRight
} from 'lucide-react';
import { orderService } from '../services/orderService';

interface OrderDetailsViewProps {
  lang: Language;
  orderId: string;
  onBack: () => void;
  products: Product[];
  onUpdateStatus: (id: string, status: OrderStatus) => void;
  onBookCourier: (id: string) => Promise<void>;
}

const OrderDetailsView: React.FC<OrderDetailsViewProps> = ({ 
  lang, 
  orderId, 
  onBack, 
  products,
  onUpdateStatus,
  onBookCourier 
}) => {
  const t = TRANSLATIONS[lang];
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        const data = await orderService.getById(orderId);
        setOrder(data);
      } catch (err) {
        console.error("Failed to fetch order details", err);
      } finally {
        setLoading(false);
      }
    };
    fetchOrder();
  }, [orderId]);

  const handleStatusUpdate = async (newStatus: OrderStatus) => {
    try {
      await onUpdateStatus(orderId, newStatus);
      const updated = await orderService.getById(orderId);
      setOrder(updated);
    } catch (err) {
      console.error("Status update failed", err);
    }
  };

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-4 border-indigo-600 border-t-transparent"></div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="p-8 text-center space-y-4">
        <p className="text-slate-500 font-bold uppercase text-[10px] tracking-widest">Order not found</p>
        <button onClick={onBack} className="text-indigo-600 font-black text-[10px] uppercase tracking-widest">Go Back</button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-slate-500 hover:text-slate-900 transition-colors font-black uppercase text-[10px] tracking-widest"
        >
          <ArrowLeft size={16} /> Back to Orders
        </button>
        <div className="flex items-center gap-2">
          <span className={`px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border-2 ${STATUS_COLORS[order.status]}`}>
            {order.status}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Panel: Customer Info */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-50 pb-3">Customer Details</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center text-slate-400 shrink-0">
                  <User size={16} />
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Name</p>
                  <p className="text-sm font-bold text-slate-800">{order.customerName}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center text-slate-400 shrink-0">
                  <Phone size={16} />
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Phone</p>
                  <p className="text-sm font-bold text-slate-800">{order.phone}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center text-slate-400 shrink-0">
                  <MapPin size={16} />
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Address</p>
                  <p className="text-sm font-bold text-slate-800">{order.address}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-50 pb-3">Order Note</h3>
            <p className="text-sm font-medium text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100 italic">
              {order.note || "No specific instructions provided."}
            </p>
          </div>
        </div>

        {/* Center: Products & Summary */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
              <h3 className="text-[10px] font-black text-slate-900 uppercase tracking-widest">Items & Inventory</h3>
            </div>
            <div className="p-0">
              {order.items.length === 0 ? (
                <div className="p-12 text-center text-slate-400 text-[10px] font-black uppercase tracking-widest">No products added</div>
              ) : (
                <table className="w-full text-left">
                  <thead>
                    <tr className="text-[9px] text-slate-400 uppercase font-black tracking-widest border-b border-slate-50">
                      <th className="px-6 py-3">Product</th>
                      <th className="px-6 py-3 text-center">Qty</th>
                      <th className="px-6 py-3 text-right">Price</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {order.items.map((item, idx) => {
                      const prod = products.find(p => p.id === item.productId);
                      return (
                        <tr key={idx} className="hover:bg-slate-50 transition-colors">
                          <td className="px-6 py-4">
                            <div className="text-xs font-black text-slate-800">{prod?.name || "Unknown Product"}</div>
                            <div className="text-[9px] text-slate-400 font-bold uppercase">{prod?.sku || "N/A"}</div>
                          </td>
                          <td className="px-6 py-4 text-center text-xs font-black text-slate-600">{item.quantity}</td>
                          <td className="px-6 py-4 text-right text-xs font-black text-slate-800">{t.currency}{(item.price * item.quantity).toLocaleString()}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
            <div className="p-6 bg-slate-900 text-white flex justify-between items-center">
              <span className="text-[10px] font-black uppercase tracking-widest opacity-60">Grand Total</span>
              <span className="text-2xl font-black">{t.currency}{order.total.toLocaleString()}</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6 border-b border-slate-50 pb-3">Timeline</h3>
            <div className="relative space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-[1px] before:bg-slate-100">
              <TimelineItem 
                icon={<Clock size={12} />} 
                title="Order Created" 
                time={new Date(order.createdAt).toLocaleString()} 
                active 
              />
              <TimelineItem 
                icon={<CheckCircle size={12} />} 
                title={`Status Changed: ${order.status}`} 
                time="Recent activity" 
                active={order.status !== OrderStatus.PENDING}
              />
              {order.trackingId && (
                <TimelineItem 
                  icon={<Truck size={12} />} 
                  title={`Booked with Steadfast`} 
                  time={`Tracking: ${order.trackingId}`} 
                  active 
                />
              )}
            </div>
          </div>
        </div>

        {/* Right Panel: Actions & Meta */}
        <div className="lg:col-span-3 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-50 pb-3">Order Controls</h3>
            
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Update Status</label>
              <select 
                value={order.status}
                onChange={(e) => handleStatusUpdate(e.target.value as OrderStatus)}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black uppercase tracking-widest outline-none focus:border-indigo-500 transition-all cursor-pointer"
              >
                {Object.values(OrderStatus).map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>

            <div className="pt-4 space-y-3">
              {order.status === OrderStatus.CONFIRMED && !order.trackingId && (
                <button 
                  onClick={() => onBookCourier(order.id)}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-orange-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-orange-600/20 hover:bg-orange-700 transition-all"
                >
                  <Truck size={14} /> Book Steadfast
                </button>
              )}
              
              <button 
                onClick={() => handleStatusUpdate(OrderStatus.CANCELLED)}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-white border border-red-200 text-red-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-50 transition-all"
              >
                <XCircle size={14} /> Cancel Order
              </button>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
             <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-50 pb-3">Payment Info</h3>
             <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">COD Amount</span>
                  <span className="text-sm font-black text-slate-800">{t.currency}{order.codAmount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Method</span>
                  <span className="text-[10px] font-black px-2 py-0.5 bg-slate-100 rounded uppercase">Cash on Delivery</span>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const TimelineItem = ({ icon, title, time, active }: any) => (
  <div className="relative pl-8">
    <div className={`absolute left-0 top-0.5 w-4 h-4 rounded-full flex items-center justify-center z-10 ${active ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20' : 'bg-slate-100 text-slate-400'}`}>
      {icon}
    </div>
    <div className="space-y-0.5">
      <p className={`text-[11px] font-black uppercase tracking-tight ${active ? 'text-slate-900' : 'text-slate-400'}`}>{title}</p>
      <p className="text-[10px] text-slate-400 font-bold">{time}</p>
    </div>
  </div>
);

export default OrderDetailsView;
