
import React from 'react';
import { Language, Order, OrderStatus, CourierType } from '../types';
import { TRANSLATIONS } from '../constants';
import { Truck, Search, MapPin, Package, ExternalLink, Timer, CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';

interface LogisticsViewProps {
  lang: Language;
  orders: Order[];
  onUpdateStatus: (id: string, status: OrderStatus) => void;
  onTrackSteadfast: (id: string) => Promise<void>;
}

const LogisticsView: React.FC<LogisticsViewProps> = ({ lang, orders, onUpdateStatus, onTrackSteadfast }) => {
  const t = TRANSLATIONS[lang];
  
  // Filter only Steadfast shipments
  const steadfastOrders = orders.filter(o => o.courierType === CourierType.STEADFAST);
  const inTransitOrders = steadfastOrders.filter(o => o.status === OrderStatus.SHIPPED);
  const pendingShipment = orders.filter(o => (o.status === OrderStatus.CONFIRMED || o.status === OrderStatus.PACKED) && !o.trackingId);

  const getCourierLogo = (type?: CourierType) => {
    switch (type) {
      case CourierType.STEADFAST: return <div className="px-2 py-0.5 bg-orange-100 text-orange-700 text-[10px] font-black rounded uppercase">Steadfast</div>;
      default: return <div className="px-2 py-0.5 bg-slate-100 text-slate-500 text-[10px] font-black rounded uppercase">Self</div>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <Truck className="text-indigo-600" size={24} />
            Steadfast Logistics Manager
          </h1>
          <p className="text-slate-500 text-xs font-medium mt-1">Real-time DB-synced consignment tracking</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard icon={<Timer className="text-blue-600" />} label="Pending Shipment" value={pendingShipment.length} color="border-blue-100 bg-blue-50/30" />
        <StatCard icon={<Truck className="text-indigo-600" />} label="In Transit" value={inTransitOrders.length} color="border-indigo-100 bg-indigo-50/30" />
        <StatCard icon={<CheckCircle2 className="text-green-600" />} label="Delivered" value={steadfastOrders.filter(o => o.status === OrderStatus.DELIVERED).length} color="border-green-100 bg-green-50/30" />
        <StatCard icon={<AlertCircle className="text-red-600" />} label="Issues" value={steadfastOrders.filter(o => o.status === OrderStatus.RETURNED).length} color="border-red-100 bg-red-50/30" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h3 className="font-black text-slate-900 text-xs uppercase tracking-widest">Courier Shipments (DB)</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="text-[10px] text-slate-400 uppercase font-black tracking-widest border-b border-slate-50 bg-slate-50/30">
                    <th className="px-6 py-3">Order ID</th>
                    <th className="px-6 py-3">Tracking ID</th>
                    <th className="px-6 py-3 text-center">Status</th>
                    <th className="px-6 py-3">COD Amount</th>
                    <th className="px-6 py-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {steadfastOrders.map(order => (
                    <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="text-xs font-black text-slate-900">#{order.id.slice(0,8)}</div>
                        <div className="text-[9px] text-slate-400 font-bold">{order.customerName}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-xs font-black text-indigo-600 uppercase tracking-tighter">{order.trackingId || 'N/A'}</div>
                        <div className="text-[9px] text-slate-400">{order.courierId || '-'}</div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest ${order.status === OrderStatus.DELIVERED ? 'bg-green-100 text-green-700' : 'bg-indigo-100 text-indigo-700'}`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-xs font-black text-slate-900">{t.currency}{order.codAmount.toLocaleString()}</div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        {order.trackingId && (
                           <button 
                            onClick={() => onTrackSteadfast(order.id)}
                            className="flex items-center gap-1 px-3 py-1.5 bg-slate-100 text-slate-700 rounded-lg text-[9px] font-black uppercase hover:bg-slate-200 transition-all border border-slate-200"
                           >
                            <RefreshCw size={10} /> Track
                           </button>
                        )}
                      </td>
                    </tr>
                  ))}
                  {steadfastOrders.length === 0 && (
                    <tr><td colSpan={5} className="py-12 text-center text-slate-400 text-xs font-bold uppercase tracking-widest">No Steadfast shipments found in DB</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="font-black text-slate-900 text-xs uppercase tracking-widest mb-4">Awaiting Handover</h3>
            <div className="space-y-3">
              {pendingShipment.slice(0, 5).map(order => (
                <div key={order.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between group cursor-pointer hover:border-indigo-200 transition-all">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-[10px] font-black">
                      #{order.id.slice(-3)}
                    </div>
                    <div>
                      <p className="text-[11px] font-black text-slate-800">{order.customerName}</p>
                      <p className="text-[9px] text-slate-500 font-bold">{order.phone}</p>
                    </div>
                  </div>
                  <button onClick={() => onUpdateStatus(order.id, OrderStatus.SHIPPED)} className="p-1.5 opacity-0 group-hover:opacity-100 bg-white border border-slate-200 rounded text-indigo-600 hover:bg-indigo-600 hover:text-white transition-all">
                    <CheckCircle2 size={14} />
                  </button>
                </div>
              ))}
              {pendingShipment.length === 0 && (
                <div className="py-6 text-center text-slate-400 text-[10px] font-bold uppercase">All orders handled</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ icon, label, value, color }: any) => (
  <div className={`p-4 rounded-xl border flex items-center gap-4 transition-all hover:shadow-md ${color}`}>
    <div className="w-10 h-10 rounded-lg bg-white shadow-sm flex items-center justify-center border border-slate-100">{icon}</div>
    <div>
      <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{label}</p>
      <h4 className="text-xl font-black text-slate-900">{value}</h4>
    </div>
  </div>
);

export default LogisticsView;
