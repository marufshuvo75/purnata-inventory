
import React from 'react';
import { Language, Customer } from '../types';
import { TRANSLATIONS } from '../constants';
import { User, ShieldAlert, Phone, CreditCard, ShoppingBag, Search } from 'lucide-react';

interface CustomersViewProps {
  lang: Language;
  customers: Customer[];
}

const CustomersView: React.FC<CustomersViewProps> = ({ lang, customers }) => {
  const t = TRANSLATIONS[lang];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">{t.customers}</h1>
          <p className="text-slate-500 text-sm">Customer insights and fraud prevention database</p>
        </div>
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Search phone or name..." 
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-lg outline-none focus:border-indigo-500 transition-all text-sm"
          />
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50 text-slate-400 text-[10px] uppercase font-bold tracking-widest">
              <th className="px-6 py-4">Customer Info</th>
              <th className="px-6 py-4 text-center">Orders</th>
              <th className="px-6 py-4 text-right">Total Spent</th>
              <th className="px-6 py-4 text-center">Loyalty Tier</th>
              <th className="px-6 py-4 text-right">Risk Score</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {customers.map(cust => {
              const riskScore = cust.isFlagged ? 'HIGH' : cust.orderCount > 1 ? 'LOW' : 'NEUTRAL';
              const riskColor = riskScore === 'HIGH' ? 'text-red-600 bg-red-50' : riskScore === 'LOW' ? 'text-green-600 bg-green-50' : 'text-slate-500 bg-slate-50';

              return (
                <tr key={cust.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 font-bold">
                        <User size={20} />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-slate-800">{cust.name}</div>
                        <div className="flex items-center gap-1 text-[10px] text-slate-400 font-bold">
                          <Phone size={10} />
                          {cust.phone}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold">
                      <ShoppingBag size={12} />
                      {cust.orderCount}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="text-sm font-bold text-slate-800">{t.currency}{cust.totalSpent.toLocaleString()}</div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${cust.totalSpent > 5000 ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-500'}`}>
                      {cust.totalSpent > 5000 ? 'Gold' : 'Silver'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-tight ${riskColor}`}>
                      {riskScore}
                    </span>
                  </td>
                </tr>
              );
            })}
            {customers.length === 0 && (
              <tr><td colSpan={5} className="py-20 text-center text-slate-400">No customer records yet</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default CustomersView;
