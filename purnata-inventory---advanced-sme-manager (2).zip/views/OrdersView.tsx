
import React, { useState, useMemo, useCallback } from 'react';
import { 
  Language, 
  Order, 
  Product, 
  OrderStatus, 
  OrderSource,
  CourierType 
} from '../types';
import { TRANSLATIONS, STATUS_COLORS } from '../constants';
import { Plus, Download, ChevronRight, X, Trash2, Loader2, Truck, RefreshCw, ShoppingBag, MapPin, Phone } from 'lucide-react';

interface OrdersViewProps {
  lang: Language;
  orders: Order[];
  products: Product[];
  onAddOrder: (order: Omit<Order, 'id' | 'createdAt'>) => Promise<string | void>;
  onUpdateStatus: (id: string, status: OrderStatus) => void;
  onBookSteadfast: (id: string) => Promise<void>;
  onTrackSteadfast: (id: string) => Promise<void>;
  onViewOrder: (id: string) => void;
}

const DISTRICTS = ["Dhaka", "Chittagong", "Rajshahi", "Khulna", "Barisal", "Sylhet", "Rangpur", "Mymensingh", "Gazipur", "Narayanganj", "Cumilla"];

const THANAS: Record<string, string[]> = {
  "Dhaka": ["Dhanmondi", "Gulshan", "Banani", "Mirpur", "Uttara", "Mohammadpur", "Badda", "Tejgaon", "Rampura", "Motijheel", "Khilgaon"],
  "Chittagong": ["Panchlaish", "Bakalia", "Kotwali", "Double Mooring", "Halishahar", "Pahartali", "Patenga"],
  "Rajshahi": ["Boalia", "Motihar", "Rajpara", "Shah Mokhdum"],
  "Gazipur": ["Gazipur Sadar", "Kaliakair", "Kaliganj", "Kapasia", "Sreepur"],
  "Narayanganj": ["Narayanganj Sadar", "Bandar", "Araihazar", "Rupganj", "Sonargaon"]
};

const OrdersView: React.FC<OrdersViewProps> = React.memo(({ 
  lang, 
  orders, 
  products, 
  onAddOrder, 
  onUpdateStatus, 
  onBookSteadfast, 
  onTrackSteadfast,
  onViewOrder
}) => {
  const t = TRANSLATIONS[lang];
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filter, setFilter] = useState<OrderStatus | 'ALL'>('ALL');
  const [submitting, setSubmitting] = useState(false);
  const [bookingId, setBookingId] = useState<string | null>(null);

  const [newOrder, setNewOrder] = useState({
    customerName: '',
    phone: '',
    address: '',
    district: '',
    thana: '',
    deliveryArea: 'inside' as 'inside' | 'outside',
    source: OrderSource.MANUAL,
    status: OrderStatus.PENDING,
    advancePayment: 0,
    note: '',
    items: [] as Array<{ productId: string; quantity: number; price: number }>
  });

  // Calculations
  const productTotal = useMemo(() => 
    newOrder.items.reduce((acc, item) => acc + (item.price * item.quantity), 0), 
  [newOrder.items]);

  const deliveryCharge = newOrder.deliveryArea === 'inside' ? 80 : 150;
  const grandTotal = productTotal + deliveryCharge;
  const codAmount = Math.max(0, grandTotal - newOrder.advancePayment);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();

    // Validations
    if (newOrder.phone.length !== 11) {
      alert("Phone number must be exactly 11 digits.");
      return;
    }
    if (!newOrder.district || !newOrder.thana) {
      alert("District and Thana must be selected.");
      return;
    }
    if (newOrder.items.length === 0) {
      alert("At least one product must be added to the order.");
      return;
    }

    setSubmitting(true);
    try {
      await onAddOrder({ 
        customerName: newOrder.customerName,
        phone: newOrder.phone,
        address: newOrder.address,
        district: newOrder.district,
        thana: newOrder.thana,
        items: newOrder.items,
        total: grandTotal, // Grand Total in 'total' field
        status: newOrder.status,
        source: newOrder.source,
        codAmount: codAmount,
        deliveryCharge: deliveryCharge,
        advancePayment: newOrder.advancePayment,
        note: newOrder.note
      });
      setIsModalOpen(false);
      setNewOrder({ customerName: '', phone: '', address: '', district: '', thana: '', deliveryArea: 'inside', source: OrderSource.MANUAL, status: OrderStatus.PENDING, advancePayment: 0, note: '', items: [] });
    } catch (err) {
      console.error("Failed to add order:", err);
    } finally {
      setSubmitting(false);
    }
  }, [newOrder, grandTotal, codAmount, deliveryCharge, onAddOrder]);

  const handleBooking = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setBookingId(id);
    try {
      await onBookSteadfast(id);
    } finally {
      setBookingId(null);
    }
  };

  const filteredOrders = useMemo(() => filter === 'ALL' ? orders : orders.filter(o => o.status === filter), [orders, filter]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-black text-slate-900 tracking-tight">{t.orders}</h1>
          <p className="text-slate-500 text-xs font-medium">Manage and fulfill your customer orders</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 px-4 py-2 text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 font-black uppercase tracking-widest text-[10px] shadow-sm">
            <Download size={14} /> Export
          </button>
          <button 
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-2 px-5 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-black uppercase tracking-widest text-[10px] shadow-lg shadow-indigo-600/20"
          >
            <Plus size={14} /> New Order
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-100 flex items-center gap-2 overflow-x-auto no-scrollbar bg-slate-50/50">
          <button onClick={() => setFilter('ALL')} className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${filter === 'ALL' ? 'bg-slate-900 text-white' : 'text-slate-500'}`}>All</button>
          {Object.values(OrderStatus).map(status => (
            <button key={status} onClick={() => setFilter(status)} className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${filter === status ? 'bg-indigo-600 text-white' : 'text-slate-500'}`}>{status}</button>
          ))}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-white text-slate-400 text-[10px] uppercase font-black tracking-widest border-b border-slate-50">
                <th className="px-6 py-4">Ref</th>
                <th className="px-6 py-4">Customer</th>
                <th className="px-6 py-4 text-right">COD Amount</th>
                <th className="px-6 py-4 text-center">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredOrders.map(order => (
                <tr 
                  key={order.id} 
                  onClick={() => onViewOrder(order.id)}
                  className="hover:bg-slate-50/50 transition-all cursor-pointer group"
                >
                  <td className="px-6 py-4 font-black text-slate-800 text-sm">#{order.id.slice(0, 8)}</td>
                  <td className="px-6 py-4">
                    <div className="text-xs font-bold text-slate-800">{order.customerName}</div>
                    <div className="text-[10px] text-slate-400 font-medium">{order.phone}</div>
                  </td>
                  <td className="px-6 py-4 text-right text-sm font-black">{t.currency}{order.codAmount.toLocaleString()}</td>
                  <td className="px-6 py-4 text-center">
                    <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border-2 ${STATUS_COLORS[order.status]}`}>
                      {order.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      {order.status === OrderStatus.CONFIRMED && !order.trackingId && (
                        <button 
                          disabled={bookingId === order.id}
                          onClick={(e) => handleBooking(e, order.id)} 
                          className="flex items-center gap-2 px-3 py-1.5 bg-orange-600 text-white rounded-lg text-[10px] font-black uppercase tracking-widest shadow-md shadow-orange-600/20 hover:bg-orange-700 transition-all"
                        >
                          {bookingId === order.id ? <Loader2 size={12} className="animate-spin" /> : <Truck size={12} />}
                          Book
                        </button>
                      )}
                      
                      <div className="p-2 text-slate-300 group-hover:text-indigo-600 group-hover:translate-x-1 transition-all">
                        <ChevronRight size={18} />
                      </div>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredOrders.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-20 text-center text-slate-400 text-[10px] font-black uppercase tracking-widest">No orders found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4 animate-in fade-in duration-100 overflow-y-auto">
          <form onSubmit={handleSubmit} className="bg-white rounded-3xl w-full max-w-4xl overflow-hidden shadow-2xl animate-in zoom-in duration-200">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <div>
                <h2 className="text-lg font-black text-slate-800 uppercase tracking-tight">Create New Order</h2>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Full customer workflow with auto-calculations</p>
              </div>
              <button type="button" onClick={() => setIsModalOpen(false)} className="p-2 text-slate-400 hover:bg-slate-200 rounded-full"><X size={18} /></button>
            </div>
            
            <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-8 max-h-[70vh] overflow-y-auto no-scrollbar">
              {/* Customer Info */}
              <div className="space-y-6">
                <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-50 pb-2">Customer Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Customer Name *</label>
                    <input required placeholder="Full Name" value={newOrder.customerName} onChange={e => setNewOrder(p => ({...p, customerName: e.target.value}))} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:bg-white focus:border-indigo-500 transition-all" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Phone Number (11 Digits) *</label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" size={14} />
                      <input required maxLength={11} placeholder="017XXXXXXXX" value={newOrder.phone} onChange={e => setNewOrder(p => ({...p, phone: e.target.value.replace(/\D/g, '')}))} className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:bg-white focus:border-indigo-500 transition-all" />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">District *</label>
                    <select required value={newOrder.district} onChange={e => setNewOrder(p => ({...p, district: e.target.value, thana: ''}))} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-black uppercase outline-none focus:bg-white focus:border-indigo-500 transition-all">
                      <option value="">Select District</option>
                      {DISTRICTS.map(d => <option key={d} value={d}>{d}</option>)}
                    </select>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Thana *</label>
                    <select required value={newOrder.thana} onChange={e => setNewOrder(p => ({...p, thana: e.target.value}))} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-black uppercase outline-none focus:bg-white focus:border-indigo-500 transition-all">
                      <option value="">Select Thana</option>
                      {(THANAS[newOrder.district] || []).map(t => <option key={t} value={t}>{t}</option>)}
                      {newOrder.district && !(THANAS[newOrder.district]) && <option value="Sadar">Sadar</option>}
                    </select>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Full Delivery Address *</label>
                  <textarea required placeholder="House, Road, Block, Area..." value={newOrder.address} onChange={e => setNewOrder(p => ({...p, address: e.target.value}))} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:bg-white focus:border-indigo-500 transition-all min-h-[80px]" />
                </div>

                <div className="space-y-3">
                  <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Delivery Location</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button 
                      type="button"
                      onClick={() => setNewOrder(p => ({...p, deliveryArea: 'inside'}))}
                      className={`flex items-center justify-center gap-2 py-3 border-2 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${newOrder.deliveryArea === 'inside' ? 'bg-indigo-50 border-indigo-600 text-indigo-700' : 'bg-slate-50 border-slate-200 text-slate-400'}`}
                    >
                      <MapPin size={14} /> Inside Dhaka (80)
                    </button>
                    <button 
                      type="button"
                      onClick={() => setNewOrder(p => ({...p, deliveryArea: 'outside'}))}
                      className={`flex items-center justify-center gap-2 py-3 border-2 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${newOrder.deliveryArea === 'outside' ? 'bg-indigo-50 border-indigo-600 text-indigo-700' : 'bg-slate-50 border-slate-200 text-slate-400'}`}
                    >
                      <Truck size={14} /> Outside Dhaka (150)
                    </button>
                  </div>
                </div>
              </div>

              {/* Items & Summary */}
              <div className="space-y-6">
                <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-50 pb-2">Products & Pricing</h3>
                
                <div className="space-y-3">
                  <div className="relative">
                    <select 
                      onChange={e => {
                        const p = products.find(prod => prod.id === e.target.value);
                        if (p) {
                          const existing = newOrder.items.findIndex(i => i.productId === p.id);
                          if (existing > -1) {
                            const updated = [...newOrder.items];
                            updated[existing].quantity += 1;
                            setNewOrder(prev => ({ ...prev, items: updated }));
                          } else {
                            setNewOrder(prev => ({...prev, items: [...prev.items, { productId: p.id, quantity: 1, price: p.sellingPrice }]}));
                          }
                        }
                        e.target.value = "";
                      }} 
                      value="" 
                      className="w-full px-4 py-3 bg-white border-2 border-dashed border-indigo-200 rounded-2xl text-[10px] font-black uppercase tracking-widest text-indigo-600 outline-none hover:border-indigo-400 transition-all cursor-pointer"
                    >
                      <option value="" disabled>+ Add Product to Order</option>
                      {products.map(p => (
                        <option key={p.id} value={p.id} disabled={p.stock <= 0}>
                          {p.name} — {t.currency}{p.sellingPrice.toLocaleString()} (Stock: {p.stock})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2 max-h-[200px] overflow-y-auto no-scrollbar pr-1">
                    {newOrder.items.map((item, idx) => {
                      const prod = products.find(p => p.id === item.productId);
                      return (
                        <div key={idx} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100 group">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-indigo-600">
                               <ShoppingBag size={14} />
                            </div>
                            <div>
                              <p className="text-[11px] font-black text-slate-800 uppercase leading-none mb-1">{prod?.name}</p>
                              <div className="flex items-center gap-2">
                                <button type="button" onClick={() => {
                                  const updated = [...newOrder.items];
                                  if (updated[idx].quantity > 1) {
                                    updated[idx].quantity -= 1;
                                    setNewOrder(prev => ({ ...prev, items: updated }));
                                  }
                                }} className="w-4 h-4 bg-white border border-slate-200 rounded flex items-center justify-center text-[10px] font-bold">-</button>
                                <span className="text-[10px] text-slate-500 font-bold">{item.quantity}</span>
                                <button type="button" onClick={() => {
                                  const updated = [...newOrder.items];
                                  updated[idx].quantity += 1;
                                  setNewOrder(prev => ({ ...prev, items: updated }));
                                }} className="w-4 h-4 bg-white border border-slate-200 rounded flex items-center justify-center text-[10px] font-bold">+</button>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <span className="text-xs font-black text-indigo-600">{t.currency}{(item.price * item.quantity).toLocaleString()}</span>
                            <button 
                              type="button"
                              onClick={() => setNewOrder(prev => ({ ...prev, items: prev.items.filter((_, i) => i !== idx) }))}
                              className="p-1.5 text-slate-300 hover:text-red-500 transition-colors"
                            >
                              <X size={14} />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Products Total</span>
                    <span className="text-xs font-black text-slate-800">{t.currency}{productTotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Delivery Charge</span>
                    <span className="text-xs font-black text-indigo-600">+{t.currency}{deliveryCharge}</span>
                  </div>
                  <div className="flex justify-between items-center pt-2 border-t border-slate-200">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Grand Total</span>
                    <span className="text-sm font-black text-slate-900">{t.currency}{grandTotal.toLocaleString()}</span>
                  </div>
                  
                  <div className="space-y-1.5 pt-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Advance Payment</label>
                    <input type="number" value={newOrder.advancePayment || ''} onChange={e => setNewOrder(p => ({...p, advancePayment: parseFloat(e.target.value) || 0}))} className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-green-600 outline-none focus:border-green-500 transition-all" placeholder="Enter advance amount if any" />
                  </div>

                  <div className="flex justify-between items-center p-4 bg-indigo-600 rounded-2xl text-white shadow-xl shadow-indigo-600/20">
                    <span className="text-[10px] font-black uppercase tracking-widest">Final COD Amount</span>
                    <span className="text-xl font-black">{t.currency}{codAmount.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-8 bg-slate-950 flex flex-col md:flex-row md:items-center justify-between border-t border-slate-900 shadow-[0_-20px_50px_rgba(0,0,0,0.2)] gap-4">
              <div className="space-y-1">
                 <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest block">Internal Order Note</label>
                 <input placeholder="Ex: Handle with care, Call before delivery" value={newOrder.note} onChange={e => setNewOrder(p => ({...p, note: e.target.value}))} className="w-full md:w-80 bg-slate-900 border border-slate-800 text-slate-300 px-4 py-2 rounded-xl text-xs font-medium outline-none focus:border-indigo-500 transition-all" />
              </div>
              <div className="flex gap-4">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)} 
                  className="px-6 py-2 text-slate-500 font-black uppercase text-[10px] tracking-widest hover:text-white transition-colors"
                >
                  Cancel
                </button>
                <button 
                  disabled={submitting} 
                  type="submit" 
                  className="px-10 py-3 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-2xl shadow-indigo-600/40 hover:bg-indigo-700 transition-all flex items-center gap-2 disabled:opacity-50"
                >
                  {submitting ? <Loader2 className="animate-spin" size={14} /> : 'Save & Confirm Order'}
                </button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
});

export default OrdersView;
