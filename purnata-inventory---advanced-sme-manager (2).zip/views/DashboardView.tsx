
import React, { useMemo } from 'react';
import { Language, Order, Product, Income, Expense, Loan, OrderStatus } from '../types';
import { TRANSLATIONS } from '../constants';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, TrendingDown, ShoppingBag, AlertCircle, Wallet, Calendar, Clock } from 'lucide-react';
import { financeService } from '../services/financeService';

interface DashboardViewProps {
  lang: Language;
  orders: Order[];
  products: Product[];
  incomes: Income[];
  expenses: Expense[];
  loans: Loan[];
}

const DashboardView: React.FC<DashboardViewProps> = ({ lang, orders, products, incomes, expenses, loans }) => {
  const t = TRANSLATIONS[lang];
  
  const financialSummary = useMemo(() => 
    financeService.calculateFinancials(incomes, expenses, orders), 
  [incomes, expenses, orders]);

  const orderStatusData = useMemo(() => [
    { name: 'Pending', value: orders.filter(o => o.status === OrderStatus.PENDING).length },
    { name: 'Confirmed', value: orders.filter(o => o.status === OrderStatus.CONFIRMED).length },
    { name: 'Shipped', value: orders.filter(o => o.status === OrderStatus.SHIPPED).length },
    { name: 'Delivered', value: orders.filter(o => o.status === OrderStatus.DELIVERED).length },
    { name: 'Returns', value: orders.filter(o => o.status === OrderStatus.RETURNED).length },
  ], [orders]);

  const chartData = useMemo(() => {
    return financialSummary.monthly.slice(0, 5).reverse().map(m => ({
      n: m.month,
      i: m.income,
      e: m.expense
    }));
  }, [financialSummary]);

  const COLORS = ['#FBBF24', '#3B82F6', '#6366F1', '#10B981', '#EF4444'];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-black text-slate-900 tracking-tight">{t.dashboard} Overview</h1>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Automatic Financial Reconciliation Active</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1 bg-white border border-slate-200 rounded-full">
           <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
           <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Live Inventory-Finance Link</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard 
          title={`${t.profit} (Today)`} 
          value={financialSummary.today.profit} 
          icon={<ShoppingBag size={18} />} 
          color="text-indigo-600 bg-indigo-50" 
        />
        <MetricCard 
          title="Total Income" 
          value={financialSummary.total.income} 
          icon={<TrendingUp size={18} />} 
          color="text-green-600 bg-green-50" 
        />
        <MetricCard 
          title="Pending COD" 
          value={financialSummary.total.pendingCOD} 
          icon={<Clock size={18} />} 
          color="text-amber-600 bg-amber-50" 
        />
        <MetricCard 
          title="Net Est. Profit" 
          value={financialSummary.total.profit} 
          icon={<Wallet size={18} />} 
          color="text-indigo-600 bg-indigo-50" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">Monthly Growth Momentum</h3>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded bg-indigo-600"></div>
                <span className="text-[9px] font-black uppercase text-slate-400">Income</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded bg-slate-200"></div>
                <span className="text-[9px] font-black uppercase text-slate-400">Expense</span>
              </div>
            </div>
          </div>
          <div className="h-[240px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="n" axisLine={false} tickLine={false} style={{fontSize: 10, fontWeight: 'bold'}} />
                <YAxis axisLine={false} tickLine={false} style={{fontSize: 10}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{borderRadius:12, border:'none', boxShadow:'0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)'}} 
                />
                <Bar dataKey="i" name="Income" fill="#6366f1" radius={[4, 4, 0, 0]} />
                <Bar dataKey="e" name="Expense" fill="#e2e8f0" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
          <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest mb-6">Order Lifecycle</h3>
          <div className="h-[200px] flex-1">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={orderStatusData} cx="50%" cy="50%" innerRadius={60} outerRadius={80} dataKey="value" paddingAngle={5}>
                  {orderStatusData.map((e, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} stroke="none" />)}
                </Pie>
                <Tooltip 
                  contentStyle={{borderRadius:8, border:'none', boxShadow:'0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-4">
            {orderStatusData.map((s, i) => (
              <div key={s.name} className="flex items-center gap-2 p-1.5 bg-slate-50 rounded-lg">
                <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: COLORS[i] }}></div>
                <span className="text-[9px] font-black text-slate-500 uppercase truncate">{s.name}: {s.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const MetricCard = ({ title, value, icon, color }: any) => (
  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4 transition-all hover:scale-[1.02] hover:shadow-md cursor-default">
    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color} shadow-sm`}>{icon}</div>
    <div>
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1.5">{title}</p>
      <h4 className="text-xl font-black text-slate-900 leading-none tracking-tight">৳{value.toLocaleString()}</h4>
    </div>
  </div>
);

export default DashboardView;
