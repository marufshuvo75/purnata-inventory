
import React, { useState } from 'react';
import { Language } from '../types';
import { TRANSLATIONS } from '../constants';
import { Loader2, Mail, ArrowRight, ShieldCheck } from 'lucide-react';
import { userService } from '../services/userService';

interface LoginViewProps {
  lang: Language;
  onLogin: (user: any) => void;
  showToast: (msg: string, type: 'success' | 'error') => void;
}

const LoginView: React.FC<LoginViewProps> = ({ lang, onLogin, showToast }) => {
  const t = TRANSLATIONS[lang];
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setLoading(true);
    try {
      const user = await userService.getUserByEmail(email);
      if (user) {
        onLogin(user);
        showToast(t.welcomeBack + ", " + user.name, 'success');
      } else {
        showToast(t.noUserFound, 'error');
      }
    } catch (err) {
      showToast("Authentication error", 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center font-black text-3xl text-white shadow-2xl shadow-indigo-600/40 mb-6 animate-in zoom-in duration-500">P</div>
          <h1 className="text-2xl font-black text-white tracking-tight text-center">{t.login}</h1>
          <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.2em] mt-2">Enterprise Resource Management</p>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-3xl p-8 shadow-2xl space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{t.emailPlaceholder}</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                autoFocus
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="email@purnata.io"
                className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold focus:bg-white focus:border-indigo-600 focus:ring-4 focus:ring-indigo-600/5 outline-none transition-all"
                required
              />
            </div>
          </div>

          <button 
            disabled={loading}
            type="submit" 
            className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl hover:bg-indigo-600 transition-all active:scale-[0.98] flex items-center justify-center gap-3 group disabled:opacity-50"
          >
            {loading ? (
              <Loader2 className="animate-spin" size={18} />
            ) : (
              <>
                {t.loginButton}
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </>
            )}
          </button>
        </form>

        <div className="mt-8 flex items-center justify-center gap-2">
          <ShieldCheck size={14} className="text-indigo-400" />
          <p className="text-slate-500 text-[9px] font-bold uppercase tracking-widest">Secure Role-Based Access Control Active</p>
        </div>
      </div>
    </div>
  );
};

export default LoginView;
