
import React, { useState } from 'react';
import { Language, UserRole, AppUser } from '../types';
import { TRANSLATIONS, ROLE_PERMISSIONS } from '../constants';
import { UserPlus, Shield, Mail, Phone, X, Trash2, CheckSquare, Square } from 'lucide-react';

interface StaffViewProps {
  lang: Language;
  users: AppUser[];
  currentUser: AppUser;
  onAddUser: (u: Omit<AppUser, 'id' | 'lastActive'>) => Promise<void>;
  onDeleteUser: (id: string) => Promise<void>;
}

const ALL_MODULES = ['dashboard', 'orders', 'inventory', 'logistics', 'customers', 'financials', 'loans', 'staff', 'settings'];

const StaffView: React.FC<StaffViewProps> = ({ lang, users, currentUser, onAddUser, onDeleteUser }) => {
  const t = TRANSLATIONS[lang];
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    role: UserRole.STAFF,
    permissions: ROLE_PERMISSIONS[UserRole.STAFF]
  });

  const togglePermission = (mod: string) => {
    setNewUser(p => ({
      ...p,
      permissions: p.permissions.includes(mod) 
        ? p.permissions.filter(m => m !== mod) 
        : [...p.permissions, mod]
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (users.length >= 11) return alert("System limited to 11 users total (Owner + 10 staff)");
    setSubmitting(true);
    try {
      await onAddUser(newUser);
      setIsModalOpen(false);
      setNewUser({ name: '', email: '', role: UserRole.STAFF, permissions: ROLE_PERMISSIONS[UserRole.STAFF] });
    } finally { setSubmitting(false); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-black text-slate-900 tracking-tight">{t.staff}</h1>
          <p className="text-slate-500 text-xs font-medium mt-1">Manage team access and role-based permissions</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-5 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 font-black uppercase tracking-widest text-[10px] transition-all shadow-xl"
        >
          <UserPlus size={14} /> Invite New Staff Member
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {users.map(person => (
          <div key={person.id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative group hover:border-indigo-200 transition-all flex flex-col">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-4">
                <div className="w-11 h-11 bg-slate-100 text-slate-500 border border-slate-200 rounded-xl flex items-center justify-center font-black text-lg">
                  {person.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-black text-slate-800 tracking-tight leading-none">{person.name}</h4>
                  <p className="text-[10px] text-slate-400 font-bold mt-1 uppercase tracking-widest">Active: {person.lastActive}</p>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest border ${person.role === UserRole.OWNER ? 'bg-purple-50 text-purple-700 border-purple-100' : 'bg-slate-50 text-slate-600 border-slate-200'}`}>
                {person.role}
              </span>
            </div>

            <div className="space-y-2 mb-6 flex-1">
              <div className="flex items-center gap-2 text-[10px] text-slate-500 font-bold uppercase tracking-tight">
                <Mail size={12} className="text-slate-300" /> {person.email}
              </div>
              <div className="flex flex-wrap gap-1 mt-3">
                {person.permissions.slice(0, 4).map(p => (
                  <span key={p} className="px-1.5 py-0.5 bg-indigo-50 text-indigo-600 text-[8px] font-black uppercase rounded">{p}</span>
                ))}
                {person.permissions.length > 4 && <span className="px-1.5 py-0.5 bg-slate-100 text-slate-500 text-[8px] font-black uppercase rounded">+{person.permissions.length - 4} more</span>}
              </div>
            </div>

            <div className="flex items-center gap-2 pt-4 border-t border-slate-50">
              <button className="flex-1 py-1.5 bg-slate-50 text-slate-600 rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-slate-100 transition-all">Edit Rights</button>
              {person.role !== UserRole.OWNER && (
                <button onClick={() => onDeleteUser(person.id)} className="p-1.5 text-red-300 hover:text-red-600 transition-all"><Trash2 size={16} /></button>
              )}
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <form onSubmit={handleSubmit} className="bg-white rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <div>
                <h2 className="text-lg font-black text-slate-800 uppercase tracking-tight">Invite Staff Member</h2>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Assign role and custom module permissions</p>
              </div>
              <button type="button" onClick={() => setIsModalOpen(false)} className="p-2 text-slate-400 hover:text-slate-600 rounded-full"><X size={18} /></button>
            </div>
            <div className="p-6 space-y-5">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Full Name</label>
                  <input required value={newUser.name} onChange={e => setNewUser(p => ({...p, name: e.target.value}))} type="text" className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 outline-none transition-all text-sm font-bold" />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Email Address</label>
                  <input required value={newUser.email} onChange={e => setNewUser(p => ({...p, email: e.target.value}))} type="email" className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 outline-none transition-all text-sm font-bold" />
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">System Role</label>
                <select 
                  value={newUser.role} 
                  onChange={e => {
                    const r = e.target.value as UserRole;
                    setNewUser(p => ({...p, role: r, permissions: ROLE_PERMISSIONS[r]}));
                  }} 
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-black uppercase outline-none"
                >
                  {Object.values(UserRole).filter(r => r !== UserRole.OWNER).map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Module Permissions</label>
                <div className="grid grid-cols-3 gap-2">
                  {ALL_MODULES.map(mod => (
                    <button 
                      key={mod}
                      type="button"
                      onClick={() => togglePermission(mod)}
                      className={`flex items-center gap-2 px-3 py-2 rounded-xl border text-[10px] font-black uppercase tracking-tight transition-all ${newUser.permissions.includes(mod) ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-slate-50 border-slate-100 text-slate-400'}`}
                    >
                      {newUser.permissions.includes(mod) ? <CheckSquare size={14} /> : <Square size={14} />}
                      {mod}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="p-6 bg-slate-50 flex justify-end gap-3 border-t border-slate-100">
              <button type="button" onClick={() => setIsModalOpen(false)} className="px-6 py-2 text-slate-400 font-black uppercase text-[10px] tracking-widest">Cancel</button>
              <button disabled={submitting} type="submit" className="px-8 py-2 bg-indigo-600 text-white rounded-xl font-black uppercase tracking-widest text-[10px] shadow-lg shadow-indigo-600/20 hover:bg-indigo-700 transition-all">
                {submitting ? 'Sending Invite...' : 'Create User'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default StaffView;
