
import React, { useState, useCallback } from 'react';
import { Language, Product } from '../types';
import { TRANSLATIONS } from '../constants';
import { Package, Plus, Search, MapPin, AlertTriangle, X, Loader2 } from 'lucide-react';

interface InventoryViewProps {
  lang: Language;
  products: Product[];
  onAddProduct: (p: Omit<Product, 'id'>) => Promise<void>;
}

const InventoryView: React.FC<InventoryViewProps> = React.memo(({ lang, products, onAddProduct }) => {
  const t = TRANSLATIONS[lang];
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [newP, setNewP] = useState({
    name: '',
    sku: '',
    costPrice: 0,
    sellingPrice: 0,
    stock: 0,
    warehouseId: 'W1',
    lowStockAlert: 5
  });

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await onAddProduct(newP);
      setIsModalOpen(false);
      setNewP({ name: '', sku: '', costPrice: 0, sellingPrice: 0, stock: 0, warehouseId: 'W1', lowStockAlert: 5 });
    } finally {
      setSubmitting(false);
    }
  }, [newP, onAddProduct]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-xl font-black text-slate-900 tracking-tight">{t.inventory}</h1>
        <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-black uppercase tracking-widest text-[10px] shadow-lg shadow-indigo-600/20">
          <Plus size={14} /> Add Product
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard label="Total Items" value={products.length} icon={<Package size={20} />} />
        <StatCard label="Low Stock" value={products.filter(p => p.stock <= p.lowStockAlert).length} icon={<AlertTriangle size={20} />} variant="warning" />
        <StatCard label="Warehouses" value={2} icon={<MapPin size={20} />} />
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
            <input type="text" placeholder="Search SKU or Name..." className="w-full pl-9 pr-4 py-1.5 bg-white border border-slate-200 rounded-lg text-[10px] font-bold outline-none" />
          </div>
        </div>
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50 text-slate-500 text-[10px] uppercase font-black tracking-widest border-b border-slate-100">
              <th className="px-6 py-4">Product</th>
              <th className="px-6 py-4">SKU</th>
              <th className="px-6 py-4 text-right">Price</th>
              <th className="px-6 py-4 text-center">Stock</th>
              <th className="px-6 py-4 text-right">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {products.map(p => (
              <tr key={p.id} className="hover:bg-slate-50 transition-all duration-75">
                <td className="px-6 py-4 text-xs font-black text-slate-800">{p.name}</td>
                <td className="px-6 py-4 text-[10px] font-mono font-bold text-slate-400">{p.sku}</td>
                <td className="px-6 py-4 text-right text-xs font-black text-indigo-600">{t.currency}{p.sellingPrice.toLocaleString()}</td>
                <td className="px-6 py-4 text-center text-xs font-black">{p.stock}</td>
                <td className="px-6 py-4 text-right">
                  <span className={`px-2 py-0.5 text-[9px] font-black rounded uppercase tracking-widest ${p.stock <= p.lowStockAlert ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'}`}>
                    {p.stock <= p.lowStockAlert ? 'Low' : 'OK'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4 animate-in fade-in duration-100">
          <form onSubmit={handleSubmit} className="bg-white rounded-2xl w-full max-w-lg shadow-2xl">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h2 className="text-lg font-black text-slate-800 uppercase">Add Product</h2>
              <button type="button" onClick={() => setIsModalOpen(false)} className="p-2 text-slate-400 hover:bg-slate-200 rounded-full"><X size={18} /></button>
            </div>
            <div className="p-6 space-y-4">
              <input required placeholder="Product Name" value={newP.name} onChange={e => setNewP(p => ({...p, name: e.target.value}))} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm font-bold outline-none focus:border-indigo-500" />
              <div className="grid grid-cols-2 gap-4">
                <input required placeholder="SKU" value={newP.sku} onChange={e => setNewP(p => ({...p, sku: e.target.value}))} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm font-bold outline-none focus:border-indigo-500" />
                <input required placeholder="Initial Stock" type="number" value={newP.stock} onChange={e => setNewP(p => ({...p, stock: parseInt(e.target.value)}))} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm font-bold outline-none focus:border-indigo-500" />
                <input required placeholder="Cost Price" type="number" value={newP.costPrice} onChange={e => setNewP(p => ({...p, costPrice: parseFloat(e.target.value)}))} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm font-bold outline-none focus:border-indigo-500" />
                <input required placeholder="Selling Price" type="number" value={newP.sellingPrice} onChange={e => setNewP(p => ({...p, sellingPrice: parseFloat(e.target.value)}))} className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm font-bold outline-none focus:border-indigo-500" />
              </div>
            </div>
            <div className="p-6 bg-slate-50 flex justify-end gap-3">
              <button type="button" onClick={() => setIsModalOpen(false)} className="px-6 py-2 text-slate-400 font-black uppercase text-[10px]">Cancel</button>
              <button disabled={submitting} type="submit" className="px-8 py-2 bg-indigo-600 text-white rounded-lg font-black uppercase tracking-widest text-[10px] shadow-lg flex items-center gap-2">
                {submitting ? <Loader2 className="animate-spin" size={14} /> : 'Save Product'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
});

const StatCard = ({ label, value, icon, variant }: any) => (
  <div className={`p-4 rounded-xl border flex items-center gap-4 bg-white transition-all duration-75 hover:shadow-md ${variant === 'warning' ? 'border-red-100 bg-red-50/20' : 'border-slate-200'}`}>
    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${variant === 'warning' ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-400'}`}>{icon}</div>
    <div>
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{label}</p>
      <h4 className="text-xl font-black text-slate-900 leading-none mt-1">{value}</h4>
    </div>
  </div>
);

export default InventoryView;
