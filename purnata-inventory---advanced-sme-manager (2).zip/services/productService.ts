
import { Product } from '../types';
import { supabase } from './supabaseClient';

const mapProduct = (p: any): Product => ({
  id: p.id,
  name: p.name,
  sku: p.sku,
  costPrice: Number(p.cost_price),
  sellingPrice: Number(p.selling_price),
  stock: p.stock,
  warehouseId: p.warehouse_id,
  lowStockAlert: p.low_stock_alert
});

const mapToDb = (p: Partial<Product>) => ({
  name: p.name,
  sku: p.sku,
  cost_price: p.costPrice,
  selling_price: p.sellingPrice,
  stock: p.stock,
  warehouse_id: p.warehouseId,
  low_stock_alert: p.lowStockAlert
});

export const productService = {
  async getAll(): Promise<Product[]> {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('name', { ascending: true });

    if (error) throw error;
    return (data || []).map(mapProduct);
  },

  async create(product: Omit<Product, 'id'>): Promise<Product> {
    const { data, error } = await supabase
      .from('products')
      .insert([mapToDb(product)])
      .select()
      .single();

    if (error) throw error;
    return mapProduct(data);
  },

  async update(id: string, updates: Partial<Product>): Promise<Product> {
    const { data, error } = await supabase
      .from('products')
      .update(mapToDb(updates))
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return mapProduct(data);
  }
};
