import { Order, OrderStatus, CourierType } from '../types';
import { supabase } from './supabaseClient';

const mapOrderItem = (i: any) => ({
  productId: i.product_id,
  quantity: i.quantity,
  price: Number(i.price)
});

const mapOrder = (o: any): Order => ({
  id: o.id,
  customerName: o.customer_name,
  phone: o.phone,
  address: o.address,
  district: o.district || '',
  thana: o.thana || '',
  total: Number(o.total || 0),
  status: o.status as OrderStatus,
  source: o.source,
     codAmount: Number(o.cod_amount || 0),
  deliveryCharge: Number(o.delivery_charge || 0),
  advancePayment: Number(o.advance_payment || 0),
  createdAt: o.created_at,
    items: (o.items || []).map(mapOrderItem)
});

const mapToDb = (o: Partial<Order>) => ({
  customer_name: o.customerName,
  phone: o.phone,
  address: o.address,
  district: o.district,
  thana: o.thana,
  total: o.total,
  status: o.status,
  source: o.source,
  cod_amount: o.codAmount,
  delivery_charge: o.deliveryCharge,
  advance_payment: o.advancePayment,
  grand_total: o.total
});


export const orderService = {
  async getAll(): Promise<Order[]> {
    const { data, error } = await supabase
      .from('orders')
      .select(`*, items:order_items(*)`)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return (data || []).map(mapOrder);
  },

  async getById(id: string): Promise<Order> {
    const { data, error } = await supabase
      .from('orders')
      .select(`*, items:order_items(*)`)
      .eq('id', id)
      .single();

    if (error) throw error;
    return mapOrder(data);
  },

  async create(order: Omit<Order, 'id' | 'createdAt'>): Promise<Order> {
    try {
      const { items, ...orderData } = order;

      const payload = mapToDb(orderData);

      const { data: newOrder, error: orderError } = await supabase
  .from('orders')
  .insert([mapToDb(orderData)])
  .select()
  .single();

if (orderError) {
  await supabase.from('debug_table').insert([{
    message: 'ORDER_INSERT_FAILED',
    details: JSON.stringify(orderError),
    created_at: new Date().toISOString()
  }]);
  throw orderError;
}


      if (orderError) {
        await supabase.from('debug_table').insert([{
          message: orderError.message,
          details: JSON.stringify(orderError),
          created_at: new Date().toISOString()
        }]);
        throw orderError;
      }

      const itemsWithOrderId = (items || []).map(item => ({
        order_id: newOrder.id,
        product_id: item.productId,
        quantity: item.quantity,
        price: item.price
      }));

      if (itemsWithOrderId.length > 0) {
  const { error: itemsError } = await supabase
    .from('order_items')
    .insert(itemsWithOrderId);

  if (itemsError) {
    await supabase.from('debug_table').insert([{
      message: 'ORDER_ITEMS_INSERT_FAILED',
      details: JSON.stringify(itemsError),
      created_at: new Date().toISOString()
    }]);
    throw itemsError;
  }
}


      return mapOrder({ ...newOrder, items: itemsWithOrderId });

    } catch (err: any) {
      await supabase.from('debug_table').insert([{
        message: 'ORDER CREATE FAILED',
        details: JSON.stringify(err),
        created_at: new Date().toISOString()
      }]);
      throw err;
    }
  },

  async updateStatus(id: string, status: OrderStatus): Promise<Order> {
    const { data: updated, error } = await supabase
      .from('orders')
      .update({ status })
      .eq('id', id)
      .select('*, items:order_items(*)')
      .single();

    if (error) throw error;
    return mapOrder(updated);
  },

  async updateCourierInfo(id: string, updates: { courierId?: string; courierType?: CourierType; trackingId?: string; status?: OrderStatus }): Promise<Order> {
    const { data, error } = await supabase
      .from('orders')
      .update({
        courier_id: updates.courierId || null,
        courier_type: updates.courierType || null,
        tracking_id: updates.trackingId || null,
        status: updates.status
      })
      .eq('id', id)
      .select('*, items:order_items(*)')
      .single();

    if (error) throw error;
    return mapOrder(data);
  }
};
