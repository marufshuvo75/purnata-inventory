import { createClient } from '@supabase/supabase-js';

// Hardcoded fallback credentials for this environment
const HARDCODED_URL = "https://wrzhualvfzfrnozufgej.supabase.co";
const HARDCODED_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Indyemh1YWx2Znpmcm5venVmZ2VqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njg2MzExMDEsImV4cCI6MjA4NDIwNzEwMX0.TOQE_2Wy38We4mcP9vfFEU4CRowmTIwT-Wv05EXENtY";

// Use environment variables if available, otherwise use hardcoded values
const supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || HARDCODED_URL;
const supabaseAnonKey = process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY || HARDCODED_KEY;

/**
 * Initialize Supabase client. 
 * Fallback values are provided to ensure the app connects successfully.
 */
export const supabase = createClient(supabaseUrl, supabaseAnonKey);
