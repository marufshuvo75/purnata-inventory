
// This service has been deprecated in favor of Supabase real-time persistence.
export const storage = {
  get: () => [],
  set: () => {}
};
