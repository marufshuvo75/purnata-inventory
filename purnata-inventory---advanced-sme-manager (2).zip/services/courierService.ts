
import { CourierConfig, CourierType } from '../types';
import { supabase } from './supabaseClient';

const mapCourier = (c: any): CourierConfig => ({
  type: c.type as CourierType,
  apiKey: c.api_key,
  storeId: c.store_id,
  isActive: c.is_active
});

const mapToDb = (c: Partial<CourierConfig>) => ({
  api_key: c.apiKey,
  store_id: c.storeId,
  is_active: c.isActive
});

export const courierService = {
  async getAll(): Promise<CourierConfig[]> {
    const { data, error } = await supabase
      .from('courier_configs')
      .select('*');

    if (error) throw error;
    
    const defaults = [
      { type: CourierType.PATHAO, apiKey: '', isActive: false },
      { type: CourierType.STEADFAST, apiKey: '', isActive: false },
      { type: CourierType.REDX, apiKey: '', isActive: false },
    ];

    if (!data || data.length === 0) return defaults;
    
    const results = data.map(mapCourier);
    // Merge defaults with existing records to ensure all types exist
    return defaults.map(d => results.find(r => r.type === d.type) || d);
  },

  async update(type: CourierType, updates: Partial<CourierConfig>) {
    const { error } = await supabase
      .from('courier_configs')
      .upsert({ type, ...mapToDb(updates) });

    if (error) throw error;
  }
};
