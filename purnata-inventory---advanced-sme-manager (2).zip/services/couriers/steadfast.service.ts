import { Order } from "../../types";

const BASE_URL = "https://portal.packzy.com/api/v1";

export interface SteadfastShipmentResponse {
  courier_id: string;
  tracking_id: string;
  status: string;
}

export const steadfastService = {
  // ✅ Test API connection
  async testConnection(apiKey: string, secretKey: string): Promise<boolean> {
    const res = await fetch(`${BASE_URL}/balance`, {
      headers: {
        "Api-Key": apiKey,
        "Secret-Key": secretKey
      }
    });

    if (!res.ok) {
      throw new Error("Steadfast connection failed");
    }

    return true;
  },

  // ✅ Create shipment in Steadfast
  async createShipment(order: Order, apiKey: string, secretKey: string): Promise<SteadfastShipmentResponse> {
    const res = await fetch(`${BASE_URL}/create_order`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Api-Key": apiKey,
        "Secret-Key": secretKey
      },
      body: JSON.stringify({
        invoice: order.id,
        // Fix: Use correct property name 'customerName' from Order interface
        recipient_name: order.customerName,
        recipient_phone: order.phone,
        recipient_address: order.address,
        // Fix: Use correct property name 'codAmount' from Order interface
        cod_amount: order.codAmount,
        note: "Purnata Order"
      })
    });

    const data = await res.json();

    if (!res.ok || data?.status !== 200) {
      throw new Error(data?.message || "Steadfast booking failed");
    }

    return {
      courier_id: String(data.consignment?.consignment_id || ""),
      tracking_id: data.consignment?.tracking_code || "",
      status: "SHIPPED"
    };
  },

  // ✅ Track shipment status
  async trackShipment(invoice: string, apiKey: string, secretKey: string): Promise<string> {
    const res = await fetch(`${BASE_URL}/status_by_invoice/${invoice}`, {
      headers: {
        "Api-Key": apiKey,
        "Secret-Key": secretKey
      }
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error("Steadfast tracking failed");
    }

    const s = (data.delivery_status || "").toLowerCase();

    if (s.includes("delivered")) return "DELIVERED";
    if (s.includes("cancel")) return "CANCELLED";
    if (s.includes("return")) return "RETURNED";
    if (s.includes("pending") || s.includes("review")) return "SHIPPED";

    return "PENDING";
  }
};