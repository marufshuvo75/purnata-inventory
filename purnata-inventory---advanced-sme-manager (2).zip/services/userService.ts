
import { AppUser } from '../types';
import { supabase } from './supabaseClient';

const mapUser = (u: any): AppUser => ({
  id: u.id,
  name: u.name,
  email: u.email,
  role: u.role,
  permissions: u.permissions,
  lastActive: u.last_active
});

export const userService = {
  async getAll(): Promise<AppUser[]> {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .order('name', { ascending: true });
    
    if (error) throw error;
    return (data || []).map(mapUser);
  },

  async getUserByEmail(email: string): Promise<AppUser | null> {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('email', email.toLowerCase())
      .single();

    if (error) return null;
    return mapUser(data);
  },

  async create(user: Omit<AppUser, 'id' | 'lastActive'>): Promise<AppUser> {
    const { data, error } = await supabase
      .from('users')
      .insert([{ ...user, email: user.email.toLowerCase(), last_active: 'Never' }])
      .select()
      .single();

    if (error) throw error;
    return mapUser(data);
  },

  async delete(id: string) {
    const { error } = await supabase
      .from('users')
      .delete()
      .eq('id', id);

    if (error) throw error;
  }
};
