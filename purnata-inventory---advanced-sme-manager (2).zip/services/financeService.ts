
import { Income, Expense, Loan, Order, OrderStatus, CourierType } from '../types';
import { supabase } from './supabaseClient';

const mapLoan = (l: any): Loan => ({
  id: l.id,
  provider: l.provider,
  amount: Number(l.amount),
  interestRate: Number(l.interest_rate),
  monthlyInstallment: Number(l.monthly_installment),
  paidAmount: Number(l.paid_amount),
  startDate: l.start_date,
  endDate: l.end_date,
  nextPaymentDate: l.next_payment_date
});

const mapLoanToDb = (l: Partial<Loan>) => ({
  provider: l.provider,
  amount: l.amount,
  interest_rate: l.interestRate,
  monthly_installment: l.monthlyInstallment,
  paid_amount: l.paidAmount,
  start_date: l.startDate,
  end_date: l.endDate,
  next_payment_date: l.nextPaymentDate
});

export const financeService = {
  async getIncomes(): Promise<Income[]> {
    const { data, error } = await supabase
      .from('incomes')
      .select('*')
      .order('date', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async createIncome(income: Omit<Income, 'id'>): Promise<Income> {
    const { data, error } = await supabase
      .from('incomes')
      .insert([income])
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async getExpenses(): Promise<Expense[]> {
    const { data, error } = await supabase
      .from('expenses')
      .select('*')
      .order('date', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async createExpense(expense: Omit<Expense, 'id'>): Promise<Expense> {
    const { data, error } = await supabase
      .from('expenses')
      .insert([expense])
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async getLoans(): Promise<Loan[]> {
    const { data, error } = await supabase
      .from('loans')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return (data || []).map(mapLoan);
  },

  async createLoan(loan: Omit<Loan, 'id'>): Promise<Loan> {
    const { data, error } = await supabase
      .from('loans')
      .insert([mapLoanToDb(loan)])
      .select()
      .single();
    if (error) throw error;
    return mapLoan(data);
  },

  async updateLoan(id: string, updates: Partial<Loan>) {
    const { data, error } = await supabase
      .from('loans')
      .update(mapLoanToDb(updates))
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return mapLoan(data);
  },

  /**
   * Financial Calculation Engine
   */
  calculateFinancials(incomes: Income[], expenses: Expense[], orders: Order[]) {
    const now = new Date();
    const today = now.toISOString().split('T')[0];
    
    // 1. Total Sales from Orders
    const totalOrderRevenue = orders.reduce((sum, o) => sum + o.total, 0);
    const todayOrderRevenue = orders.filter(o => o.createdAt.startsWith(today)).reduce((sum, o) => sum + o.total, 0);

    // 2. Direct Incomes
    const totalDirectIncome = incomes.reduce((sum, i) => sum + i.amount, 0);
    const todayDirectIncome = incomes.filter(i => i.date === today).reduce((sum, i) => sum + i.amount, 0);

    // 3. Total Expenses
    const totalExpense = expenses.reduce((sum, e) => sum + e.amount, 0);
    const todayExpense = expenses.filter(e => e.date === today).reduce((sum, e) => sum + e.amount, 0);

    // 4. Pending COD Tracking
    // We consider COD "Pending" if the order is shipped but not delivered, returned, or cancelled.
    const pendingCOD = orders
      .filter(o => 
        o.courierType === CourierType.STEADFAST && 
        o.status !== OrderStatus.DELIVERED && 
        o.status !== OrderStatus.CANCELLED && 
        o.status !== OrderStatus.RETURNED &&
        o.status === OrderStatus.SHIPPED
      )
      .reduce((sum, o) => sum + (o.codAmount || 0), 0);

    // 5. Summaries
    const totalIncome = totalDirectIncome + totalOrderRevenue;
    const todayIncome = todayDirectIncome + todayOrderRevenue;
    const todayProfit = todayIncome - todayExpense;

    // 6. Monthly Grouping for P&L
    const monthlySummary: Record<string, { income: number; expense: number; profit: number }> = {};
    
    incomes.forEach(i => {
      const month = i.date.substring(0, 7);
      if (!monthlySummary[month]) monthlySummary[month] = { income: 0, expense: 0, profit: 0 };
      monthlySummary[month].income += i.amount;
    });

    orders.forEach(o => {
      const month = o.createdAt.substring(0, 7);
      if (!monthlySummary[month]) monthlySummary[month] = { income: 0, expense: 0, profit: 0 };
      monthlySummary[month].income += o.total;
    });

    expenses.forEach(e => {
      const month = e.date.substring(0, 7);
      if (!monthlySummary[month]) monthlySummary[month] = { income: 0, expense: 0, profit: 0 };
      monthlySummary[month].expense += e.amount;
    });

    Object.keys(monthlySummary).forEach(month => {
      monthlySummary[month].profit = monthlySummary[month].income - monthlySummary[month].expense;
    });

    return {
      today: {
        income: todayIncome,
        expense: todayExpense,
        profit: todayProfit,
        salesCount: orders.filter(o => o.createdAt.startsWith(today)).length
      },
      total: {
        income: totalIncome,
        expense: totalExpense,
        profit: totalIncome - totalExpense,
        pendingCOD
      },
      monthly: Object.entries(monthlySummary)
        .sort((a, b) => b[0].localeCompare(a[0]))
        .map(([month, data]) => ({ month, ...data }))
    };
  }
};
