
// This file is deprecated and preserved for backward compatibility. 
// Use the specific services in services/* for faster lookups and better performance.

import { productService } from './productService';
import { orderService } from './orderService';
import { financeService } from './financeService';
import { userService } from './userService';
import { courierService } from './courierService';

export const api = {
  getProducts: () => productService.getAll(),
  createProduct: (p: any) => productService.create(p),
  updateProduct: (id: string, u: any) => productService.update(id, u),

  getOrders: () => orderService.getAll(),
  createOrder: (o: any) => orderService.create(o),
  updateOrderStatus: (id: string, s: any) => orderService.updateStatus(id, s),

  getIncomes: () => financeService.getIncomes(),
  createIncome: (i: any) => financeService.createIncome(i),
  getExpenses: () => financeService.getExpenses(),
  createExpense: (e: any) => financeService.createExpense(e),
  getLoans: () => financeService.getLoans(),
  createLoan: (l: any) => financeService.createLoan(l),
  updateLoan: (id: string, u: any) => financeService.updateLoan(id, u),

  getUsers: () => userService.getAll(),
  createUser: (u: any) => userService.create(u),
  deleteUser: (id: string) => userService.delete(id),

  getCourierConfigs: () => courierService.getAll(),
  updateCourierConfig: (t: any, u: any) => courierService.update(t, u)
};
